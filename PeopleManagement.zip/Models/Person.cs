﻿namespace PeopleManagement.Models;

public class Person
{
    public int No { get; set; }
    public string Name { get; set; } = string.Empty;
    public int Age { get; set; }
}
